import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ticket-book-success',
  templateUrl: './ticket-book-success.component.html',
  styleUrls: ['./ticket-book-success.component.css']
})
export class TicketBookSuccessComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  test(){
    
  }

}
